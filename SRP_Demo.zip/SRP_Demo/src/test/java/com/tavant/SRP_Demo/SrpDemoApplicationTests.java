package com.tavant.SRP_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrpDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
