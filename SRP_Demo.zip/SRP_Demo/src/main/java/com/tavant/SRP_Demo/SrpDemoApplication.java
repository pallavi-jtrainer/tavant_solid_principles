package com.tavant.SRP_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrpDemoApplication.class, args);
	}

}
